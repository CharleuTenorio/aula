<?php
session_start();
include('../verifica_login.php');
include_once('../conexao.php');


?>


<!DOCTYPE html>

<head>
<link rel="stylesheet" href="../css/formesimples.css">

</head>

<body>


<div id="navbar">
  <a class="active" href="javascript:void(0)">Olá, <?php echo $_SESSION['email'];?></a>
  <a href="adm_familia.php">Principal</a>
  <a href="../logout.php">Sair</a>
</div>

<div class="content">
<?php
 
$ID=mysqli_escape_string($conn,trim($_POST['id']));
 $n_caixa =mysqli_escape_string($conn,trim($_POST['n_caixa'])) ;
 $n_pasta =mysqli_escape_string($conn,trim($_POST['n_pasta'])) ;
 $cod_home =mysqli_escape_string($conn,trim($_POST['cod_home'])) ;
 $bairro =mysqli_escape_string($conn,trim($_POST['bairro'])) ;
 $date_interview =mysqli_escape_string($conn,trim($_POST['date_interview'])) ;
 $date_visit=mysqli_escape_string($conn,trim($_POST['date_visit'])) ;
 $motivo =mysqli_escape_string($conn,trim($_POST['motivo'])) ;
 $observacao =mysqli_escape_string($conn,trim($_POST['observacao'])) ;
 //campos checkbox tem que ter esse formato

 $checkbox1=$_POST['escolhas'];
 $chk="";

 foreach($checkbox1 as $chk1)  
   {  
      $chk .= $chk1.",";  
   }  
 
 
// fim 


//  inicio da conssulta para delimitar o número de pastas por caixas

$query = "SELECT COUNT(*) AS TOTAL FROM  pasta where id_caixa='$n_caixa'";

if ($stmt = mysqli_prepare($conn, $query))
{
    
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $total);
    mysqli_stmt_fetch($stmt);   
    mysqli_stmt_close($stmt);
}





// fim do numero de consulta para delimitar pasta por caixa 


//inicio do if para ver se o numere de pasta é permitido 





 $sql="UPDATE boxes SET num_box='$n_caixa',num_paste='$n_pasta',cod_home='$cod_home',bairro='$bairro',
 data_entrevista='$date_interview',data_visita='$date_visit',
 motivo='$motivo',observacao='$observacao',estado='$chk' WHERE id='$ID'" ;
 
  
  
      if(mysqli_query($conn,$sql)){
          echo("Atualizado : $n_pasta com sucesso");
          

          $conn->close();
            
       
        
      }
      else
      {
          echo("Não foi possível Atualizar");
          
      }
   

  

  ?>
</div>

<a href="consult_pasta.php">Voltar</a><br>


<script>
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;

function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
</script>




<footer>
</footer>


</body>


